<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Admin Panel - View Appointments</title>

	<!-- Bootstrap CSS -->
	<link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
	<!-- Font Awesome Icons -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
	<!-- Custom Theme CSS -->
	<link href="css/theme.css" rel="stylesheet" media="all">

	<!-- Custom CSS -->
	<style>
		/* Page Background */
		body {
			background: linear-gradient(to bottom, #f4f8fb, #eaf0f6);
			font-family: 'Arial', sans-serif;
		}

		/* Styling for table header */
		.table thead th {
			background: linear-gradient(45deg, #007BFF, #0056b3);
			color: #fff;
			font-size: 16px;
			font-weight: bold;
		}

		/* Hover effects for table rows */
		.table tbody tr:hover {
			background-color: #f1f8ff;
			transition: background-color 0.3s ease;
		}

		/* Center text and vertically align */
		.table td,
		.table th {
			vertical-align: middle;
			text-align: center;
		}

		/* Table container */
		.table-responsive {
			margin-top: 20px;
			padding: 15px;
			border-radius: 10px;
			background: #fff;
			box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
		}

		/* Card styling */
		.card {
			border-radius: 15px;
			box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15);
			background: white;
		}

		.card-header {
			background: linear-gradient(45deg, #6a11cb, #2575fc);
			color: #fff;
			border-radius: 15px 15px 0 0;
			font-size: 18px;
			font-weight: bold;
			text-align: center;
		}

		/* Button hover effects */
		.btn-primary {
			background: linear-gradient(45deg, #6a11cb, #2575fc);
			border: none;
			color: white;
		}

		.btn-primary:hover {
			background: linear-gradient(45deg, #2575fc, #6a11cb);
			transform: scale(1.05);
			transition: all 0.3s ease;
		}

		.btn-danger {
			background-color: #e74c3c;
			border: none;
			color: white;
		}

		.btn-danger:hover {
			background-color: #c0392b;
			transform: scale(1.05);
			transition: all 0.3s ease;
		}

		/* Sidebar styling */
		.menu-sidebar {
			background: #1a1a2e;
			color: white;
		}

		.menu-sidebar .navbar__list li a {
			color: white;
			font-weight: bold;
			text-transform: uppercase;
			padding: 10px;
		}

		.menu-sidebar .navbar__list li a:hover {
			color: #2575fc;
			transition: all 0.3s;
		}

		/* Animation */
		@keyframes fadeIn {
			from {
				opacity: 0;
				transform: translateY(20px);
			}
			to {
				opacity: 1;
				transform: translateY(0);
			}
		}

		.card {
			animation: fadeIn 0.8s ease-out;
		}

		/* Responsive adjustments */
		@media (max-width: 768px) {
			.table {
				font-size: 12px;
			}
		}
	</style>
</head>

<body>
	<div class="page-wrapper">
		<!-- MENU SIDEBAR -->
		<aside class="menu-sidebar d-none d-lg-block">
			<div class="logo">
				<a href="#">
					<img src="images/icon/logo1.png" alt="CoolAdmin" height="80px" width="80px">
				</a>
				<h3>Admin</h3>
			</div>
			<div class="menu-sidebar__content js-scrollbar1">
				<nav class="navbar-sidebar">
					<ul class="list-unstyled navbar__list">
						<li>
							<a href="#">
								<i class="fas fa-tachometer-alt"></i>Dashboard</a>
						</li>
						<li>
							<a href="#">
								<i class="fas fa-table"></i>View Appointments</a>
						</li>
						<li>
							<a href="../index.html">
								<i class="fas fa-sign-out-alt"></i>Logout</a>
						</li>
					</ul>
				</nav>
			</div>
		</aside>
		<!-- END MENU SIDEBAR -->

		<!-- PAGE CONTAINER -->
		<div class="page-container">
			<!-- HEADER DESKTOP -->
			<header class="header-desktop">
				<div class="section__content section__content--p30">
					<div class="container-fluid">
						<div class="header-wrap">
							<form class="form-header" action="" method="POST">
								<input class="au-input au-input--xl" type="text" name="search" placeholder="Search for data &amp; reports..." />
								<button class="au-btn--submit btn btn-primary" type="submit">
									<i>↻</i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</header>
			<!-- HEADER DESKTOP -->

			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="section__content section__content--p30">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-12">
								<div class="card">
									<div class="card-header">
										<strong class="card-title">View Appointments</strong>
									</div>
									<div class="card-body">
										<!-- District Selection Form -->
										<form method="POST" action="">
											<label for="district">Select District:</label>
											<select id="district" name="district" class="form-control" required>
												<option value="" disabled selected>Select a district</option>
												<?php
												$districts = [
													"Nandurbar", "Ahmednagar", "Akola", "Amravati", "Beed", "Bhandara",
													"Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli",
													"Jalgaon", "Jalna", "Kolhapur", "Latur", "Mumbai City", "Mumbai Suburban",
													"Nagpur", "Nanded", "Nashik", "Dharashiv", "Palghar", "Parbhani",
													"Pune", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg",
													"Solapur", "Thane", "Wardha", "Washim", "Yavatmal", "Sambhajinagar"
												];
												foreach ($districts as $district) {
													echo "<option value=\"$district\">$district</option>";
												}
												?>
											</select>
											<button type="submit" class="btn btn-primary mt-3">View Appointments</button>
										</form>

										<!-- Handle Deletion -->
										<?php
										if ($_SERVER['REQUEST_METHOD'] === 'POST') {
											$servername = "localhost";
											$username = "root";
											$password = "";
											$dbname = "DistrictAppointments";
											$conn = new mysqli($servername, $username, $password, $dbname);

											if ($conn->connect_error) {
												die("Connection failed: " . $conn->connect_error);
											}

											// Handle Delete Request
											if (isset($_POST['delete_id'])) {
												$delete_id = $_POST['delete_id'];
												$delete_district = $_POST['delete_district'];
												$delete_sql = "DELETE FROM `$delete_district` WHERE id = $delete_id";
												if ($conn->query($delete_sql) === TRUE) {
													echo "<p class='text-success'>Appointment deleted successfully.</p>";
												} else {
													echo "<p class='text-danger'>Error deleting appointment: " . $conn->error . "</p>";
												}
											}

											// Handle District Selection
											if (isset($_POST['district'])) {
												$selectedDistrict = $_POST['district'];
												echo "<h3 class='mt-4'>Appointments for District: <strong>$selectedDistrict</strong></h3>";

												$sql = "SELECT * FROM `$selectedDistrict`";
												$result = $conn->query($sql);

												if ($result && $result->num_rows > 0) {
													echo "<div class='table-responsive mt-4'>";
													echo "<table class='table table-hover table-bordered text-center'>";
													echo "<thead>";
													echo "<tr>
															<th>#</th>
															<th>Name</th>
															<th>Email</th>
															<th>Phone</th>
															<th>Age</th>
															<th>Gender</th>
															<th>Appointment Date</th>
															<th>Symptoms</th>
															<th>Actions</th>
														  </tr>";
													echo "</thead>";
													echo "<tbody>";
													while ($row = $result->fetch_assoc()) {
														echo "<tr>
																<td>{$row['id']}</td>
																<td>{$row['name']}</td>
																<td>{$row['email']}</td>
																<td>{$row['phone']}</td>
																<td>{$row['age']}</td>
																<td>" . ucfirst($row['gender']) . "</td>
																<td>{$row['appointment_date']}</td>
																<td>{$row['symptoms']}</td>
																<td>
																	<form method='POST' action='' style='display: inline-block;'>
																		<input type='hidden' name='delete_id' value='{$row['id']}'>
																		<input type='hidden' name='delete_district' value='$selectedDistrict'>
																		<button type='submit' class='btn btn-danger btn-sm'>Delete</button>
																	</form>
																</td>
															</tr>";
													}
													echo "</tbody>";
													echo "</table>";
													echo "</div>";
												} else {
													echo "<p class='text-danger mt-4'>No records found for the selected district.</p>";
												}
											}

											$conn->close();
										}
										?>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="copyright">
									<p>Copyright © 2025. All rights reserved.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>

	<script src="vendor/bootstrap-4.1/popper.min.js"></script>
	<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
</body>

</html>
