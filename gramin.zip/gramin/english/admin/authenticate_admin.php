<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get input data from the form
$email = $_POST['email'];
$password = $_POST['password'];

// echo $email;
// echo $password;
// // Prepare and execute SQL query to check email and fetch the corresponding password
$sql = "SELECT password FROM users WHERE email ='$email' and password='$password' ";
$res=mysqli_query($conn,$sql);
$i=0;
while ($d=mysqli_fetch_row($res))
{
    $i++;
}
if ($i>0)
{

    header("Location: alert.php");
    
}
else
{
    echo "INCORECT ID AND PASSWORD";
}

?>
