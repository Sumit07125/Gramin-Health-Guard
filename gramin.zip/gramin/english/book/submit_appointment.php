<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "DistrictAppointments";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$district = $_POST['district'];
$appointment_date = $_POST['appointment_date'];
$symptoms = $_POST['symptoms'];

// Ensure the district table exists
$district = $conn->real_escape_string($district); // Prevent SQL injection

// SQL query to insert the data into the selected district's table
$sql = "INSERT INTO `$district` (name, email, phone, age, gender, appointment_date, symptoms) 
        VALUES ('$name', '$email', '$phone', $age, '$gender', '$appointment_date', '$symptoms')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "<h2>Appointment booked successfully!</h2>";
    echo "<p>Thank you, $name. Your appointment has been scheduled for $appointment_date in the $district district.</p>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>