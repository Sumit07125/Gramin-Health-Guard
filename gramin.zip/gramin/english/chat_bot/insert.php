<?php
// Database connection details
$host = 'localhost'; // Change this to your database host
$db = 'fetch'; // Your database name
$user = 'root'; // Your database username
$password = ''; // Your database password

// Connect to the database
$conn = new mysqli($host, $user, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $user_message = $conn->real_escape_string($_POST['user_message']);
    $bot_response = $conn->real_escape_string($_POST['bot_response']);

    // Insert data into the table
    $sql = "INSERT INTO chatbot_responses (user_message, bot_response) VALUES ('$user_message', '$bot_response')";

    if ($conn->query($sql) === TRUE) {
        $url = "succes.html";

$handle = fopen($url, "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        echo $line; // Outputs the webpage content line by line
    }
    fclose($handle);
} else {
    echo "Failed to open the webpage.";
}
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
